# Employability Skills Portfolio

This folder contains the website files for GitHub Pages.

## Publish the website

1. Create a **public** GitHub repository named `employability-skills-portfolio`.
2. Upload both `index.html` and `london_bus_vending.png` to the repository's top level.
3. Open **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Select branch `main` and folder `/ (root)`, then click **Save**.
6. After GitHub finishes publishing, visit:

   https://chrisdias20.github.io/employability-skills-portfolio/

The website may take a few minutes to appear. Check the URL in a private/incognito browser window before submitting it.

## Important
The webpage is a static portfolio. Review the wording and make sure every statement accurately reflects work you personally completed. Add any required university cover sheet and AI-use declaration to your separate PDF submission.
